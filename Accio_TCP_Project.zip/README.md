# Project-1-Accio

*Zilong Wang   zilongwang

*based on the source codes that the course offers, I added codes deal with wrong port number and IP address, as well as timeout part. Most important thing is to code about file transfer. Most of them I used C to write, but for some I used C++ too.

*Problems:
# file contents received by the server has unusual characters, that original file is differ than transfered file  --- fixed by changing transfer contents size from 1024 to whatever they are.
# cannot pass tests for the server to receive files --- fixed by delete codes that deal with '/' in the path. Thanks Bhavana for the helps.
# Didn't know how to deal with timeout --- figured out by doing lots of reseaches.

*None additional library used

* Acknowledgement
# https://blog.csdn.net/q1007729991/article/details/71078044 --- helps with my timeout code
# watched some youtube videos about socket, and did some researches as well.
