#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>

#include <iostream>
#include <sstream>
using namespace std ;
int main(int argc, char **argv)
{
  // create a socket using TCP IP
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);

  struct sockaddr_in serverAddr;
  serverAddr.sin_family = AF_INET;
  int port1 = atoi(argv[2]);
  if (port1 <= 1023) {
    std::cerr << "ERROR: invalid port" << std::endl;
    return 1.5;
  }
  serverAddr.sin_port = htons(atoi(argv[2]));     // short, network byte order
  if ((strcmp(argv[1], "localhost") == 0) || (strcmp(argv[1], "127.0.0.1") == 0))
  {
      serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
  }
  else {
      std::cerr << "ERROR: invalid hostname" << std::endl;
      return 1.5;
  }
  //serverAddr.sin_addr.s_addr = inet_addr(ip);
  memset(serverAddr.sin_zero, '\0', sizeof(serverAddr.sin_zero));

  // connect to the server
  if (connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1) {
    std::cerr << "ERROR: connect fail" << std::endl;
    return 2;
  }

  struct sockaddr_in clientAddr;
  socklen_t clientAddrLen = sizeof(clientAddr);
  if (getsockname(sockfd, (struct sockaddr *)&clientAddr, &clientAddrLen) == -1) {
    perror("getsockname");
    return 3;
  }

  char ipstr[INET_ADDRSTRLEN] = {'\0'};
  inet_ntop(clientAddr.sin_family, &clientAddr.sin_addr, ipstr, sizeof(ipstr));
  std::cout << "Set up a connection from: " << ipstr << ":" <<
    ntohs(clientAddr.sin_port) << std::endl;

  std::stringstream ss;

    FILE *fp = fopen(argv[3], "rb");
  
  char buff[1024];
  struct timeval timeout;
    timeout.tv_sec = 10;
    timeout.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

  while(1) {
      memset(buff, 0, 1024);
      int len = fread(buff, 1, 1024, fp);
      if (len > 0) {
          send(sockfd, buff, len, 0);
      }
      else{
          if (errno == EWOULDBLOCK)
            std::cerr << "ERROR: timeout" << std::endl;
          perror("send");
          break;
      }
    }
  fclose(fp);

  close(sockfd);

  return 0;
}